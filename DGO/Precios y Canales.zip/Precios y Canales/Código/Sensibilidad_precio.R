# ------------------------------------------------------------
# ANÁLISIS DESCRIPTIVO Y ESTIMACIÓN DE ELASTICIDAD PRECIO-DEMANDA
# ------------------------------------------------------------

# Librerías necesarias
library(dplyr)
library(ggplot2)
library(readr)
library(broom)
library(tidyr)


# ------------------------------------------------------------
# 1. CONFIGURACIÓN DE RUTAS
# ------------------------------------------------------------
input_path <- "C:/Users/owoc9/Documents/U Javeriana/Laboratorio Analítica/DGO/Precios y Canales/Insumos/supermarket_sales.csv"
output_path <- "C:/Users/owoc9/Documents/U Javeriana/Laboratorio Analítica/DGO/Precios y Canales/Resultados/"

if(!dir.exists(output_path)) dir.create(output_path, recursive = TRUE)

# ------------------------------------------------------------
# 2. LECTURA Y RENOMBRADO DE VARIABLES
# ------------------------------------------------------------
data <- read.csv(input_path, sep = ";")

# Renombrar columnas con formato limpio
data <- data %>%
  rename(
    invoice_id = Invoice.ID,
    branch = Branch,
    city = City,
    customer_type = Customer.type,
    gender = Gender,
    product_line = Product.line,
    unit_price = Unit.price,
    quantity = Quantity,
    tax_5 = Tax.5.,
    total = Total,
    date = Date,
    time = Time,
    payment = Payment,
    cogs = cogs,
    gross_margin_percentage = gross.margin.percentage,
    gross_income = gross.income,
    rating = Rating
  )

# Mostrar primeras filas
cat("\n--- Vista preliminar de los datos ---\n")
print(head(data))

# ------------------------------------------------------------
# 3. ANÁLISIS DESCRIPTIVO UNIVARIADO
# ------------------------------------------------------------

cat("\n--- Resumen general de variables numéricas ---\n")
print(summary(select(data, unit_price, quantity, total, cogs, gross_income, rating)))

cat("\n--- Distribución de variables categóricas ---\n")
categorical_vars <- c("branch", "city", "customer_type", "gender", "product_line", "payment")
for (var in categorical_vars) {
  cat(paste0("\nFrecuencias de ", var, ":\n"))
  print(table(data[[var]]))
}

# Gráficos univariados
ggplot(data, aes(x = unit_price)) + 
  geom_histogram(binwidth = 5, fill = "steelblue", color = "white") +
  labs(title = "Distribución del Precio Unitario", x = "Precio Unitario", y = "Frecuencia")

ggplot(data, aes(x = quantity)) + 
  geom_histogram(binwidth = 1, fill = "orange", color = "white") +
  labs(title = "Distribución de Cantidad", x = "Cantidad", y = "Frecuencia")

# ------------------------------------------------------------
# 4. ANÁLISIS BIVARIADO: PRECIO vs CANTIDAD
# ------------------------------------------------------------

cat("\n--- Correlación entre precio y cantidad ---\n")
print(cor(data$unit_price, data$quantity))

ggplot(data, aes(x = unit_price, y = quantity)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  labs(title = "Relación Precio - Cantidad", x = "Precio Unitario", y = "Cantidad Vendida")

# ------------------------------------------------------------
# 5. MODELO DE ELASTICIDAD PRECIO - DEMANDA POR CANAL (BRANCH)
# ------------------------------------------------------------

cat("\n--- Estimación de elasticidad precio-demanda por sucursal ---\n")

# Transformaciones logarítmicas
data <- data %>%
  mutate(
    log_price = log(unit_price),
    log_quantity = log(quantity)
  )

# Estimación por canal (branch)
elasticity_models <- data %>%
  group_by(branch) %>%
  do(model = lm(log_quantity ~ log_price, data = .)) %>%
  mutate(tidy_model = list(tidy(model))) %>%
  select(branch, tidy_model) %>%
  unnest(cols = tidy_model) %>%
  filter(term == "log_price") %>%
  rename(elasticity = estimate)

cat("\n--- Resultados de elasticidad por canal ---\n")
print(elasticity_models)

# Exportar resultados
write.csv(elasticity_models, file.path(output_path, "elasticidad_por_branch.csv"), row.names = FALSE)

# ------------------------------------------------------------
# 6. INTERPRETACIÓN AUTOMÁTICA BÁSICA
# ------------------------------------------------------------
cat("\n--- Interpretación básica ---\n")
for (i in 1:nrow(elasticity_models)) {
  b <- elasticity_models$branch[i]
  e <- elasticity_models$elasticity[i]
  msg <- ifelse(e < -1,
                "Demanda elástica: la cantidad responde fuertemente al precio.",
                ifelse(e > -1 & e < 0,
                       "Demanda inelástica: la cantidad responde poco al precio.",
                       "Relación no negativa o inusual."))
  cat(paste0("Sucursal ", b, ": Elasticidad = ", round(e, 3), " → ", msg, "\n"))
}

cat("\n--- Proceso finalizado. Resultados exportados y mostrados en consola. ---\n")

